<ul>
				<li><a href="uhome.php">Home</li>
				<li><a href="search_books.php">Search Books</li>
				<li><a href="request.php">Request</li>
				<li><a href="uchangepass.php">Change Password</li>
				<li><a href="logout.php">Logout</li>
</ul>