<?php
session_start();
include "database.php";
if(!isset($_SESSION["ID"])){
	header("location:ulogin.php");
}
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>Library</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body>
		<div id="container">
			<div id="header">
				<h1>Library Management System</h1>
			</div>
			<div id="wrapper">
			  <h3 id="heading">Welcome <?php echo $_SESSION["NAME"];?></h3>
			  <center><img src="img/2.png" height="272" style="float:center" width="300">
			  <p>* No opening or closing hours
</p><p>* Multiple and simultaneous access</p>
<p>* Library management automation</p>
<p>* Access to multiple contents with a potentially infinite number of resources and selections</p>
<p>* Access to materials at any time of the day</p></center>
			  </div>
			 
			<div id="navi">
				<?php 
					include "usidebar.php"
				?>
			</div>
			 </div>
		
		
		</div>
	</body>
</html>
