<!DOCTYPE HTML>
<html>
	<head>
		<title>Library</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body>
		<div id="container">
			<div id="header">
				<h1>Library Management System</h1>
			</div>
			<div id="wrapper">
			  <h1 ><center>Welcome to your Library</center></h1>
			  <center><img src="img/1.png" height="272" style="float:center" width="300"></center>
			  <p>The first modern library in India was the Asiatic Society of Bengal, which was established in 1784. The first public library in India was the State Central Library of Kerala, which was established in 1829. The Raja Rammohun Roy Library Foundation was established in 1972 by the Government of India to promote the development of public libraries in the country.  
The National Library of India in Kolkata originated from the Calcutta Public Library. The National Library is open from 9 AM to 8 PM on working days and from 9:30 AM to 6 PM on Saturdays, Sundays, and Government of India holidays. </p>
</div>
			<div id="navi">
				<?php 
					include "sidebar.php"
				?>
			</div>
			
			
		
		</div>
	</body>
</html>