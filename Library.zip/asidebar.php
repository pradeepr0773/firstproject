<ul>
				<li><a href="ahome.php">Home</li>
				<li><a href="view_student.php">View Student</li>
				<li><a href="upload_books.php">Upload Books</li>
				<li><a href="view_books.php">View Books</li>
				<li><a href="view_req.php">View Request</li>
				<li><a href="view_comm.php">View Comments</li>
				<li><a href="achangepass.php">Change Password</li>
				<li><a href="logout.php">Logout</li>
</ul>