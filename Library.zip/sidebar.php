<ul>
				<li><a href="alogin.php">Admin Login</li>
				<li><a href="ulogin.php">User Login</li>
				<li><a href="new.php">User Register</li>
				
				</ul>