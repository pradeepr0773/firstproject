<?php
session_start();
include "database.php";
function countRecord($sql,$db){
	$res=$db->query($sql);
	return $res->num_rows;
}
if(!isset($_SESSION["AID"])){
	header("location:alogin.php");
}
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>Library</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body>
		<div id="container">
			<div id="header">
				<h1>Library Management System</h1>
			</div>
			<div id="wrapper">
			  <h3 id="heading">Welcome Admin</h3>
			  <div id="center">
			  <ul>
					<li>Total Students  : <?php echo countRecord("SELECT * FROM student",$db);?></li>
					<li>Total Books:<?php echo countRecord("SELECT * FROM book",$db);?></li>
					<li>Total Request:<?php echo countRecord("SELECT * FROM request",$db);?></li>
					<li>Total Comments:<?php echo countRecord("SELECT * FROM comment",$db);?></li>
			  </ul>
			  </div>
			  </div>
			 
			<div id="navi">
				<?php 
					include "asidebar.php"
				?>
			</div>
			 </div>
			
			
		
		</div>
	</body>
</html>
