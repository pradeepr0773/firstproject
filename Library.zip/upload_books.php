<?php
session_start();
include "database.php";
function countRecord($sql,$db){
	$res=$db->query($sql);
	return $res->num_rows;
}
if(!isset($_SESSION["AID"])){
	header("location:alogin.php");
}
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>Library</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body>
		<div id="container">
			<div id="header">
				<h1>Library Management System</h1>
			</div>
			<div id="wrapper">
			  <h3 id="heading">Upload Books</h3>
			  <div id="center">
			  <?php
					if(isset($_POST["submit"])){
					$target_dir="upload/";
					$target_file=$target_dir.basename($_FILES["efile"]["name"]);
						
						if(move_uploaded_file($_FILES["efile"]["tmp_name"],$target_file)){
							$sql="insert into book(BTITLE,KEYWORDS,FILE) values('{$_POST["bname"]}','{$_POST["keys"]}','{$target_file}')";
							$db->query($sql);
							echo"<p class='success'>Upload Successfully</p>";
						}
						else{
							echo "<p class='error'></p>";
						}
					}
			  ?>
			  <form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post" enctype="multipart/form-data">
			  <label>Book Title</label>
			  <input type="text" name="bname" required>
			  <label>Keyword</label>
			  <textarea name="keys" required></textarea>
			  <label>Upload File</label>
			  <input type="file" name="efile" required>
			  <button type="submit" name="submit">Upload Books</button>
			  </form>
			  </div>
			  
			  </div>
			 
			<div id="navi">
				<?php 
					include "asidebar.php"
				?>
			</div>
			 </div>
			
			
		
		</div>
	</body>
</html>
